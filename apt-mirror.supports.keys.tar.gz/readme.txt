Description:

This version has been patched to work with private keys and certs in case you need
to access a protected apt repository.

Note: This has been tested on Ubuntu 10.x, so use it with a grain of salt anywhere else.

To install:

After you have installed apt-mirror, replace the installed script with this version.
On my machine, it was in /usr/bin/apt-mirror. You will also need to update
/etc/apt/mirror.list with the additional options if you wish to use them. This version
should be completely backwards compatible with the bundled version. If not, please
let me know.


Thanks,
-elb-

Elbert Lai
theelbster@gmail.com
